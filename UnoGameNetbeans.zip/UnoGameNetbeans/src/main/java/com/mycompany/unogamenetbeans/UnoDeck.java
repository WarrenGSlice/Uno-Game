/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.unogamenetbeans;

import java.util.ArrayList;
import java.util.Random;
import javax.swing.ImageIcon;


public class UnoDeck {
//creates the deck
	private UnoCard[] cards;
	private int cardsInDeck;
	
	public UnoDeck() {
		//an array with 108 cards
		cards = new UnoCard[108];
                reset();
	}
	
	public void reset() {
		UnoCard.Color[] colors = UnoCard.Color.values();//card array for colors
		cardsInDeck = 0;
		
		for(int i=0; i<colors.length-1; i++) {
			UnoCard.Color color = colors[i];
			
			cards[cardsInDeck++] = new UnoCard(color, UnoCard.Value.getValue(0));
			
			for(int j=1; j<10; j++) {//did it twice cuz we need 2 cards 1-9
				cards[cardsInDeck++] = new UnoCard(color,UnoCard.Value.getValue(j));
				cards[cardsInDeck++] = new UnoCard(color,UnoCard.Value.getValue(j));
			}
			
			UnoCard.Value[] values = new UnoCard.Value[] {UnoCard.Value.DrawTwo,UnoCard.Value.Skip,UnoCard.Value.Reverse};
					//starts at first value in the array values and then makes two of each value
			for(UnoCard.Value value : values) {
				cards[cardsInDeck++] = new UnoCard(color,value);
				cards[cardsInDeck++] = new UnoCard(color,value);
			}
		}
		//creates the wild and wild four cards
		UnoCard.Value[] values = new UnoCard.Value[] {UnoCard.Value.Wild, UnoCard.Value.Wild_Four};
		for(UnoCard.Value value : values) {
			for(int i = 0; i < 4; i++) {
				cards[cardsInDeck++] = new UnoCard(UnoCard.Color.Wild, value);
			}
		}
	}
	//when cards run out, replaces current deck with the stockpile of discards
	public void replaceDeckWith(ArrayList<UnoCard> cards) {
		this.cards = cards.toArray(new UnoCard[cards.size()]);//taking this array list of uno cards and turns it into a normal arraylist of unocards
		//this stockpile is being turned into the new deck
		this.cardsInDeck = this.cards.length;//the amount of cards in the deck is the length of this array
	}
	//return true if there are no cards left in deck
	public boolean isEmpty() {
		return cardsInDeck == 0;
	}
	//method to shuffle cards in deck
	public void shuffle() {
		int n= cards.length;//will be amount of cards in deck
		Random random = new Random();
		//get a random index of the array past the current index
		//swap the random element with the present element
		for(int i=0; i<cards.length; i++) {
			int randomValue = i + random.nextInt(n - i);
			UnoCard randomCard = cards[randomValue];
			cards[randomValue] = cards[i];//puts the first card in the deck at the position of the random value
			cards[i] = randomCard;//puts random card in the first position of the deck array
			
		}
		
	}
	//draw card method that returns a singular uno card
	public UnoCard drawCard() throws IllegalArgumentException {//if you cant play a card but you need to draw a card from the deck and its empty
		if (isEmpty()) {
			throw new IllegalArgumentException("Cannot draw a card since there are no Cards in the deck*");
		}//this has the user draw from the top card on the deck if this happens
		return cards[--cardsInDeck];
	}
	//creates an image of the card for the previous exception
	public ImageIcon drawCardImage() throws IllegalArgumentException{
		if(isEmpty()) {
			throw new IllegalArgumentException ("Cannot draw a card since the deck is empty");
		}
		return new ImageIcon(cards[--cardsInDeck].toString() + ".png");
	}
	
	//draw card method for multiple cards, if you get hit with a draw 4 or draw 2, this will return an array of uno cards
	public UnoCard[] drawCard(int n) {
		if(n<0) {
			throw new IllegalArgumentException("Must draw positive cards but tried to draw " + n + " cards.");
		}
		//if you try to draw more cards than what is in the deck
		if (n > cardsInDeck) {
			throw new IllegalArgumentException("Cannot draw " + n + " cards since there are only " + cardsInDeck + " cards.");
		}
		
		UnoCard[] ret = new UnoCard[n];
		
		for(int i = 0; i < n; i++) {//fill up the array with cards from the deck
			ret[i] = cards[--cardsInDeck];
		}//returns the array, if you try to draw negative cards it will stop from doing that.
		return ret;
	}
}
